"""
Galaxy tagging classes and methods.
"""
