webapps Package
===============

:mod:`webapps` Package
----------------------

.. automodule:: galaxy.webapps
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.webapps.community
    galaxy.webapps.demo_sequencer
    galaxy.webapps.galaxy
    galaxy.webapps.reports

