splitters Package
=================

:mod:`basic` Module
-------------------

.. automodule:: galaxy.jobs.splitters.basic
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`multi` Module
-------------------

.. automodule:: galaxy.jobs.splitters.multi
    :members:
    :undoc-members:
    :show-inheritance:

