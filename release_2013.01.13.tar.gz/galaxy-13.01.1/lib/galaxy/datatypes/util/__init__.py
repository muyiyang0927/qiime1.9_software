"""
Utilities for Galaxy datatypes.
"""