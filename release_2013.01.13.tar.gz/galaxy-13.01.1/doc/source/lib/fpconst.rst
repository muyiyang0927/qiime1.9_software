fpconst Module
==============

.. automodule:: fpconst
    :members:
    :undoc-members:
    :show-inheritance:
