genome_index Package
====================

:mod:`genome_index` Package
---------------------------

.. automodule:: galaxy.tools.genome_index
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`index_genome` Module
--------------------------

.. automodule:: galaxy.tools.genome_index.index_genome
    :members:
    :undoc-members:
    :show-inheritance:

