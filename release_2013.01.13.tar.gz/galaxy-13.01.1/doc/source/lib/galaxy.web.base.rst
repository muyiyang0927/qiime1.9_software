base Package
============

:mod:`controller` Module
------------------------

.. automodule:: galaxy.web.base.controller
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.web.base.controllers

