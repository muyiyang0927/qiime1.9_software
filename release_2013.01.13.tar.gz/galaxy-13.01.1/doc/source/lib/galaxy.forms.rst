forms Package
=============

:mod:`forms` Module
-------------------

.. automodule:: galaxy.forms.forms
    :members:
    :undoc-members:
    :show-inheritance:

