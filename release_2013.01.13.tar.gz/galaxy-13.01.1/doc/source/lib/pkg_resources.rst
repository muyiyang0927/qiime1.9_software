pkg_resources Module
====================

.. automodule:: pkg_resources
    :members:
    :undoc-members:
    :show-inheritance:
