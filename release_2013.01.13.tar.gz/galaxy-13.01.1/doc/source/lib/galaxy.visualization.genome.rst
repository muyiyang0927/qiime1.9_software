genome Package
==============

:mod:`genome` Package
---------------------

.. automodule:: galaxy.visualization.genome
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`visual_analytics` Module
------------------------------

.. automodule:: galaxy.visualization.genome.visual_analytics
    :members:
    :undoc-members:
    :show-inheritance:

