orm Package
===========

:mod:`orm` Package
------------------

.. automodule:: galaxy.model.orm
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`logging_connection_proxy` Module
--------------------------------------

.. automodule:: galaxy.model.orm.logging_connection_proxy
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.model.orm.ext

