"""
Galaxy specific SQLAlchemy extensions.
"""