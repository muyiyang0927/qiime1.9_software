actions Package
===============

:mod:`admin` Module
-------------------

.. automodule:: galaxy.actions.admin
    :members:
    :undoc-members:
    :show-inheritance:

