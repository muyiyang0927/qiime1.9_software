migrate Package
===============

:mod:`check` Module
-------------------

.. automodule:: galaxy.tool_shed.migrate.check
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`common` Module
--------------------

.. automodule:: galaxy.tool_shed.migrate.common
    :members:
    :undoc-members:
    :show-inheritance:

