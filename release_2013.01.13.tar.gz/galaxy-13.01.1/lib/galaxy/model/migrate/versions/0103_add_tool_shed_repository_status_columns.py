"""Migration script to add status and error_message columns to the tool_shed_repository table."""

from sqlalchemy import *
from sqlalchemy.orm import *
from migrate import *
from migrate.changeset import *

import datetime
now = datetime.datetime.utcnow
# Need our custom types, but don't import anything else from model
from galaxy.model.custom_types import *

metadata = MetaData( migrate_engine )
db_session = scoped_session( sessionmaker( bind=migrate_engine, autoflush=False, autocommit=True ) )

def upgrade():
    print __doc__
    metadata.reflect()
    ToolShedRepository_table = Table( "tool_shed_repository", metadata, autoload=True )
    # Add the status column to the tool_shed_repository table.
    col = Column( "status", TrimmedString( 255 ) )
    try:
        col.create( ToolShedRepository_table )
        assert col is ToolShedRepository_table.c.status
    except Exception, e:
        print "Adding status column to the tool_shed_repository table failed: %s" % str( e )
    # Add the error_message column to the tool_shed_repository table.
    col = Column( "error_message", TEXT )
    try:
        col.create( ToolShedRepository_table )
        assert col is ToolShedRepository_table.c.error_message
    except Exception, e:
        print "Adding error_message column to the tool_shed_repository table failed: %s" % str( e )
    # Update the status column value for tool_shed_repositories to the default value 'Installed'.
    cmd = "UPDATE tool_shed_repository SET status = 'Installed';"
    try:
        db_session.execute( cmd )
    except Exception, e:
        print "Exception executing sql command: "
        print cmd
        print str( e )
    # Update the status column for tool_shed_repositories that have been uninstalled.
    cmd = "UPDATE tool_shed_repository SET status = 'Uninstalled' WHERE uninstalled;"
    try:
        db_session.execute( cmd )
    except Exception, e:
        print "Exception executing sql command: "
        print cmd
        print str( e )
    # Update the status column for tool_shed_repositories that have been deactivated.
    cmd = "UPDATE tool_shed_repository SET status = 'Deactivated' where deleted and not uninstalled;"
    try:
        db_session.execute( cmd )
    except Exception, e:
        print "Exception executing sql command: "
        print cmd
        print str( e )
def downgrade():
    metadata.reflect()
    ToolShedRepository_table = Table( "tool_shed_repository", metadata, autoload=True )
    try:
        ToolShedRepository_table.c.status.drop()
    except Exception, e:
        print "Dropping column status from the tool_shed_repository table failed: %s" % str( e )
    try:
        ToolShedRepository_table.c.error_message.drop()
    except Exception, e:
        print "Dropping column error_message from the tool_shed_repository table failed: %s" % str( e )
