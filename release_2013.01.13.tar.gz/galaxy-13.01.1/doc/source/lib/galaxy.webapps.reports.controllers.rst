controllers Package
===================

:mod:`controllers` Package
--------------------------

.. automodule:: galaxy.webapps.reports.controllers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`jobs` Module
------------------

.. automodule:: galaxy.webapps.reports.controllers.jobs
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`root` Module
------------------

.. automodule:: galaxy.webapps.reports.controllers.root
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`sample_tracking` Module
-----------------------------

.. automodule:: galaxy.webapps.reports.controllers.sample_tracking
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`system` Module
--------------------

.. automodule:: galaxy.webapps.reports.controllers.system
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`users` Module
-------------------

.. automodule:: galaxy.webapps.reports.controllers.users
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`workflows` Module
-----------------------

.. automodule:: galaxy.webapps.reports.controllers.workflows
    :members:
    :undoc-members:
    :show-inheritance:

