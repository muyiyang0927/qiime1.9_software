#!/bin/bash -x

rm info/*
rm out/*

