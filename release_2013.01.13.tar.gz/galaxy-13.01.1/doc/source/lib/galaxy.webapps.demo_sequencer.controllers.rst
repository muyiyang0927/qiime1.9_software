controllers Package
===================

:mod:`controllers` Package
--------------------------

.. automodule:: galaxy.webapps.demo_sequencer.controllers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`common` Module
--------------------

.. automodule:: galaxy.webapps.demo_sequencer.controllers.common
    :members:
    :undoc-members:
    :show-inheritance:

