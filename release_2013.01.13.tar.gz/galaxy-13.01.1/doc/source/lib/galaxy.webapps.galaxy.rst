galaxy Package
==============

:mod:`buildapp` Module
----------------------

.. automodule:: galaxy.webapps.galaxy.buildapp
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.webapps.galaxy.api
    galaxy.webapps.galaxy.controllers

