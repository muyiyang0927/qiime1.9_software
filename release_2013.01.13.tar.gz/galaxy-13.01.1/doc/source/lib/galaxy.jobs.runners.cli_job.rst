cli_job Package
===============

:mod:`cli_job` Package
----------------------

.. automodule:: galaxy.jobs.runners.cli_job
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`torque` Module
--------------------

.. automodule:: galaxy.jobs.runners.cli_job.torque
    :members:
    :undoc-members:
    :show-inheritance:

