"""
OpenID functionality
"""