display_applications Package
============================

:mod:`application` Module
-------------------------

.. automodule:: galaxy.datatypes.display_applications.application
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`parameters` Module
------------------------

.. automodule:: galaxy.datatypes.display_applications.parameters
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`util` Module
------------------

.. automodule:: galaxy.datatypes.display_applications.util
    :members:
    :undoc-members:
    :show-inheritance:

