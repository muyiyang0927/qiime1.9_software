tags Package
============

:mod:`tags` Package
-------------------

.. automodule:: galaxy.tags
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tag_handler` Module
-------------------------

.. automodule:: galaxy.tags.tag_handler
    :members:
    :undoc-members:
    :show-inheritance:

