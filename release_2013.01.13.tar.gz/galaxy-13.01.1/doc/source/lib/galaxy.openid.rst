openid Package
==============

:mod:`openid` Package
---------------------

.. automodule:: galaxy.openid
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`providers` Module
-----------------------

.. automodule:: galaxy.openid.providers
    :members:
    :undoc-members:
    :show-inheritance:

