cli_shell Package
=================

:mod:`cli_shell` Package
------------------------

.. automodule:: galaxy.jobs.runners.cli_shell
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`rsh` Module
-----------------

.. automodule:: galaxy.jobs.runners.cli_shell.rsh
    :members:
    :undoc-members:
    :show-inheritance:

