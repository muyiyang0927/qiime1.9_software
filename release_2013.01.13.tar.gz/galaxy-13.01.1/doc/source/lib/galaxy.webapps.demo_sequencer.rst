demo_sequencer Package
======================

:mod:`demo_sequencer` Package
-----------------------------

.. automodule:: galaxy.webapps.demo_sequencer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`app` Module
-----------------

.. automodule:: galaxy.webapps.demo_sequencer.app
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`buildapp` Module
----------------------

.. automodule:: galaxy.webapps.demo_sequencer.buildapp
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`config` Module
--------------------

.. automodule:: galaxy.webapps.demo_sequencer.config
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`registry` Module
----------------------

.. automodule:: galaxy.webapps.demo_sequencer.registry
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.webapps.demo_sequencer.controllers
    galaxy.webapps.demo_sequencer.framework

