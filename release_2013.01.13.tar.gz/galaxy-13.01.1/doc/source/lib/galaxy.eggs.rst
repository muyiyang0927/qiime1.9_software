eggs Package
============

:mod:`eggs` Package
-------------------

.. automodule:: galaxy.eggs
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dist` Module
------------------

.. automodule:: galaxy.eggs.dist
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`scramble` Module
----------------------

.. automodule:: galaxy.eggs.scramble
    :members:
    :undoc-members:
    :show-inheritance:

