tracks Package
==============

:mod:`tracks` Package
---------------------

.. automodule:: galaxy.visualization.tracks
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`summary` Module
---------------------

.. automodule:: galaxy.visualization.tracks.summary
    :members:
    :undoc-members:
    :show-inheritance:

