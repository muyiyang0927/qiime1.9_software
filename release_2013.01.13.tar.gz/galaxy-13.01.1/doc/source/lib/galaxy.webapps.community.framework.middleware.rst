middleware Package
==================

:mod:`middleware` Package
-------------------------

.. automodule:: galaxy.webapps.community.framework.middleware
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`hg` Module
----------------

.. automodule:: galaxy.webapps.community.framework.middleware.hg
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`remoteuser` Module
------------------------

.. automodule:: galaxy.webapps.community.framework.middleware.remoteuser
    :members:
    :undoc-members:
    :show-inheritance:

