#ifndef ultra_h
#define ultra_h

#include "seqdb.h"
#define Ultra SeqDB
#define GetSeedLabel GetLabel

#endif // ultra_h
