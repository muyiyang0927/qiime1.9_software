framework Package
=================

:mod:`framework` Package
------------------------

.. automodule:: galaxy.webapps.demo_sequencer.framework
    :members:
    :undoc-members:
    :show-inheritance:

