"""
Utilities used by various Galaxy tools

FIXME: These are used by tool scripts, not the framework, and should not live
       in this package.
"""