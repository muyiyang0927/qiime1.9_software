search Package
==============

:mod:`search` Package
---------------------

.. automodule:: galaxy.tools.search
    :members:
    :undoc-members:
    :show-inheritance:

