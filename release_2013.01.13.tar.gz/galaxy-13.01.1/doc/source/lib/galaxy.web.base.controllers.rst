controllers Package
===================

:mod:`admin` Module
-------------------

.. automodule:: galaxy.web.base.controllers.admin
    :members:
    :undoc-members:
    :show-inheritance:

