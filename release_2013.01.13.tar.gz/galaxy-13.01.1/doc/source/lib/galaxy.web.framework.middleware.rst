middleware Package
==================

:mod:`middleware` Package
-------------------------

.. automodule:: galaxy.web.framework.middleware
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`profile` Module
---------------------

.. automodule:: galaxy.web.framework.middleware.profile
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`remoteuser` Module
------------------------

.. automodule:: galaxy.web.framework.middleware.remoteuser
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`static` Module
--------------------

.. automodule:: galaxy.web.framework.middleware.static
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`translogger` Module
-------------------------

.. automodule:: galaxy.web.framework.middleware.translogger
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`xforwardedhost` Module
----------------------------

.. automodule:: galaxy.web.framework.middleware.xforwardedhost
    :members:
    :undoc-members:
    :show-inheritance:

