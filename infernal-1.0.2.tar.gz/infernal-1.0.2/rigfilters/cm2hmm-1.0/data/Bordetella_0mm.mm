Params: ./cmzasha --learn-mm 0 /projects/bio/zasha/seqs/NCBIMicrobes/Bordetella_bronchiseptica/NC_002927.fna 
Build: release
Host: xmen.cs.washington.edu
pid: 25017
----fastaFile: /projects/bio/zasha/seqs/NCBIMicrobes/Bordetella_bronchiseptica/NC_002927.fna
----cmFile: not-a-cm-file (global)

done 1.06784e+07 nucs (frac lets thru so far=0, 2d-fracLetsThru=0).
After scanning, learned Markov model:
0-order Markov model:
order & count-dump list: ,0,1.70442e+06,3.63475e+06,3.63475e+06,1.70442e+06
conditional probs:
	A  = 0.159615
	C  = 0.340385
	G  = 0.340385
	U  = 0.159615

done 1.06784e+07 nucs (frac lets thru so far=0, 2d-fracLetsThru=0).

CPU time: 4.22u 0.04s 00:00:04.25 Elapsed: 00:00:04
