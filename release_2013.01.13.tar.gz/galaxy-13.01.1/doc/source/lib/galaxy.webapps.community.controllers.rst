controllers Package
===================

:mod:`controllers` Package
--------------------------

.. automodule:: galaxy.webapps.community.controllers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`admin` Module
-------------------

.. automodule:: galaxy.webapps.community.controllers.admin
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`common` Module
--------------------

.. automodule:: galaxy.webapps.community.controllers.common
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`hg` Module
----------------

.. automodule:: galaxy.webapps.community.controllers.hg
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`repository` Module
------------------------

.. automodule:: galaxy.webapps.community.controllers.repository
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`repository_review` Module
-------------------------------

.. automodule:: galaxy.webapps.community.controllers.repository_review
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`upload` Module
--------------------

.. automodule:: galaxy.webapps.community.controllers.upload
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`user` Module
------------------

.. automodule:: galaxy.webapps.community.controllers.user
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`workflow` Module
----------------------

.. automodule:: galaxy.webapps.community.controllers.workflow
    :members:
    :undoc-members:
    :show-inheritance:

