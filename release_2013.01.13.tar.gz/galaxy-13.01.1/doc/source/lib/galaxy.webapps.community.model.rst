model Package
=============

:mod:`model` Package
--------------------

.. automodule:: galaxy.webapps.community.model
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mapping` Module
---------------------

.. automodule:: galaxy.webapps.community.model.mapping
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.webapps.community.model.migrate

