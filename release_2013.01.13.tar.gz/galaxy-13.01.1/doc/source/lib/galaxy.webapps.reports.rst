reports Package
===============

:mod:`reports` Package
----------------------

.. automodule:: galaxy.webapps.reports
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`app` Module
-----------------

.. automodule:: galaxy.webapps.reports.app
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`buildapp` Module
----------------------

.. automodule:: galaxy.webapps.reports.buildapp
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`config` Module
--------------------

.. automodule:: galaxy.webapps.reports.config
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.webapps.reports.controllers

